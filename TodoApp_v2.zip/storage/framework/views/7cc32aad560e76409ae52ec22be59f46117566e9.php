<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="shadow-teal-300 text-white shadow-xl p-16 my-52 mx-auto  sm:w-1/2 lg:w-2/6 justify-center duration-300 bg-slate-500 rounded-xl
                    hover:shadow-xl hover:shadow-teal-500">
            <div class="text-3xl my-10 text-center"> Welcome <span class="font-extrabold">Todo App</span></div>
            <div class="my-5 text-center">
                <input type="email" name="email" :value="old('email')" required placeholder="E Mail"
                class="text-lg p-2 bg-transparent outline-none border-b-2 focus:shadow-xl focus:border-teal-300 w-full" >
            </div>
            <div class="my-5 text-center">
                <input type="password"  type="password" name="password" required autocomplete="current-password" placeholder="Password"
                class="text-lg p-2 bg-transparent outline-none border-b-2 focus:shadow-xl focus:border-teal-300  w-full " >
            </div>

                <button type="submit" class="bg-slate-900 hover:bg-slate-700 duration-300 py-2 px-6 rounded-lg uppercase text-sm w-full my-5">
                    <?php echo e(__('Log in')); ?>

                </button>
                <div class="bg-slate-900 hover:bg-slate-700 duration-300 py-2 px-6 rounded-lg uppercase text-center text-sm w-full mb-5">
                    <a href="<?php echo e(route('register')); ?>" >Register</a> 
                </div>
        </form>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Furkan\Desktop\Todo App\TodoApp_v2\resources\views/auth/login.blade.php ENDPATH**/ ?>